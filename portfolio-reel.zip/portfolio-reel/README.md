# Portfolio Reel — Remotion Project

**30-second premium motion graphics reel for Instagram (9:16)**

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Open Remotion Studio (preview in browser)
npm start

# 3. Render to MP4
npm run render

# Render at full 1080×1920
npm run render:instagram
```

## Project Structure

```
src/
├── index.ts              # Remotion entry point
├── Root.tsx              # Composition registration
├── PortfolioReel.tsx     # Main composition
├── constants.ts          # Colors, easing, utilities
├── components/
│   ├── Primitives.tsx    # Particles, Glows, Grid, Counter
│   └── SceneTransitions.tsx
└── scenes/
    ├── Scene1.tsx  (0–4s)   Kinetic typography opener
    ├── Scene2.tsx  (4–8s)   Logo reveal + headline
    ├── Scene3.tsx  (8–14s)  Rapid montage + device mockup
    ├── Scene4.tsx  (14–20s) Metrics dashboard
    ├── Scene5.tsx  (20–26s) 3D orbit portfolio cards
    └── Scene6.tsx  (26–30s) Finale + CTA explosion
```

## Customization

### Branding
Edit `src/constants.ts`:
```ts
export const CORAL = "#FF7F6A";   // ← your primary
export const CREAM = "#FFF5E8";   // ← your secondary
export const BG    = "#0B0B0B";   // ← background
```

### Text
- Scene 1: headline words → `src/scenes/Scene1.tsx`
- Scene 2: tagline → `src/scenes/Scene2.tsx`
- Scene 6: CTA handle → change `@yourstudio` in `Scene6.tsx`

### Metrics (Scene 4)
```ts
const METRICS = [
  { value: 320, prefix: "+", suffix: "%", label: "Engagement" },
  ...
];
```

### Safe Zone
The **bottom 40% (y > 1152px)** is kept dark for your talking-head overlay.
Remove the label in `PortfolioReel.tsx` before final render.

## Render Settings

| Setting | Value |
|---------|-------|
| Resolution | 1080 × 1920 |
| FPS | 30 |
| Duration | 30 s (900 frames) |
| Codec | H.264 |
| Format | Instagram Reel (9:16) |

## Requirements

- Node.js 18+
- Chrome (for Remotion rendering)
