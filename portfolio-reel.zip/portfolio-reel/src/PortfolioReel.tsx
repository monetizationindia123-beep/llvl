import React from "react";
import { useCurrentFrame, AbsoluteFill } from "remotion";
import { BG, W, H, SAFE_H, FPS, CORAL, CREAM, FONT } from "./constants";
import { Scene1 } from "./scenes/Scene1";
import { Scene2 } from "./scenes/Scene2";
import { Scene3 } from "./scenes/Scene3";
import { Scene4 } from "./scenes/Scene4";
import { Scene5 } from "./scenes/Scene5";
import { Scene6 } from "./scenes/Scene6";
import { SceneTransitions } from "./components/SceneTransitions";

// Which scene is active
function activeScene(frame: number) {
  const sec = frame / FPS;
  if (sec < 4)  return 1;
  if (sec < 8)  return 2;
  if (sec < 14) return 3;
  if (sec < 20) return 4;
  if (sec < 26) return 5;
  return 6;
}

export const PortfolioReel: React.FC = () => {
  const frame = useCurrentFrame();
  const scene = activeScene(frame);

  return (
    <AbsoluteFill style={{ background: BG, fontFamily: FONT }}>
      {/* ── Scene layers (only active scene renders) ── */}
      {scene === 1 && <Scene1 />}
      {scene === 2 && <Scene2 />}
      {scene === 3 && <Scene3 />}
      {scene === 4 && <Scene4 />}
      {scene === 5 && <Scene5 />}
      {scene === 6 && <Scene6 />}

      {/* ── Safe zone — bottom 40% always covered ── */}
      <div
        style={{
          position: "absolute",
          top: SAFE_H,
          left: 0,
          right: 0,
          bottom: 0,
          background: "#060606",
        }}
      />

      {/* Safe zone label (optional — comment out for final render) */}
      <div
        style={{
          position: "absolute",
          top: SAFE_H + 32,
          width: "100%",
          textAlign: "center",
          fontFamily: FONT,
          fontSize: 28,
          letterSpacing: "0.2em",
          color: "rgba(255,127,106,0.2)",
        }}
      >
        ↑ TALKING HEAD SAFE ZONE ↑
      </div>

      {/* ── Vignette (top 60%) ── */}
      <div
        style={{
          position: "absolute",
          top: 0, left: 0, right: 0,
          height: SAFE_H,
          background: `radial-gradient(ellipse at 50% 50%, transparent 40%, rgba(0,0,0,0.55) 100%)`,
          pointerEvents: "none",
        }}
      />

      {/* ── Scene-cut flash transitions ── */}
      <SceneTransitions />

      {/* ── Timecode watermark ── */}
      <div
        style={{
          position: "absolute",
          top: 40,
          right: 60,
          fontFamily: FONT,
          fontSize: 22,
          color: "rgba(255,245,232,0.2)",
          letterSpacing: "0.1em",
        }}
      >
        {Math.floor(frame / FPS / 60).toString().padStart(2, "0")}:
        {Math.floor((frame / FPS) % 60).toString().padStart(2, "0")}
      </div>
    </AbsoluteFill>
  );
};
