import React from "react";
import { Composition } from "remotion";
import { PortfolioReel } from "./PortfolioReel";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="PortfolioReel"
        component={PortfolioReel}
        durationInFrames={900} // 30s @ 30fps
        fps={30}
        width={1080}
        height={1920}
      />
    </>
  );
};
