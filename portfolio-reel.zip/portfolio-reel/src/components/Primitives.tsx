import React from "react";
import { CORAL, CREAM, W, SAFE_H, FONT } from "./constants";

// ─── Floating particles ───────────────────────────────────────────────────────
interface Particle {
  x: number; y: number; r: number;
  coral: boolean; baseAlpha: number;
  driftX: number; driftY: number;
}

// Deterministic seeded random so particles don't jump frame-to-frame
function seededRand(seed: number) {
  let s = seed;
  return () => {
    s = (s * 16807 + 0) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

const PARTICLES: Particle[] = (() => {
  const r = seededRand(42);
  return Array.from({ length: 70 }, () => ({
    x: r() * W,
    y: r() * SAFE_H,
    r: 2 + r() * 6,
    coral: r() > 0.55,
    baseAlpha: 0.25 + r() * 0.65,
    driftX: (r() - 0.5) * 0.4,
    driftY: -0.15 - r() * 0.35,
  }));
})();

export const Particles: React.FC<{ frame: number; opacity?: number }> = ({
  frame, opacity = 1,
}) => (
  <svg
    style={{ position: "absolute", top: 0, left: 0, width: W, height: SAFE_H, pointerEvents: "none" }}
    viewBox={`0 0 ${W} ${SAFE_H}`}
  >
    {PARTICLES.map((p, i) => {
      const t = frame / 30;
      const x = ((p.x + p.driftX * t * 60) % W + W) % W;
      const y = ((p.y + p.driftY * t * 60) % SAFE_H + SAFE_H) % SAFE_H;
      return (
        <circle
          key={i} cx={x} cy={y} r={p.r}
          fill={p.coral ? CORAL : CREAM}
          opacity={p.baseAlpha * opacity}
        />
      );
    })}
  </svg>
);

// ─── Coral streak ─────────────────────────────────────────────────────────────
export const CoralStreak: React.FC<{
  x: number; y: number; width: number; height?: number; opacity?: number;
}> = ({ x, y, width, height = 5, opacity = 0.7 }) => (
  <div
    style={{
      position: "absolute",
      left: x, top: y,
      width, height,
      borderRadius: height / 2,
      background: `linear-gradient(90deg, transparent 0%, ${CORAL} 40%, transparent 100%)`,
      opacity,
    }}
  />
);

// ─── Radial glow dot ──────────────────────────────────────────────────────────
export const GlowDot: React.FC<{
  cx: number; cy: number; radius: number; color?: string; opacity?: number;
}> = ({ cx, cy, radius, color = CORAL, opacity = 0.3 }) => (
  <div
    style={{
      position: "absolute",
      left: cx - radius, top: cy - radius,
      width: radius * 2, height: radius * 2,
      borderRadius: "50%",
      background: `radial-gradient(circle, ${color} 0%, transparent 70%)`,
      opacity,
      pointerEvents: "none",
    }}
  />
);

// ─── Animated counter ────────────────────────────────────────────────────────
export const Counter: React.FC<{
  target: number; progress: number; prefix?: string; suffix?: string;
  style?: React.CSSProperties;
}> = ({ target, progress, prefix = "", suffix = "", style }) => {
  const val = Math.round(target * progress);
  return (
    <span style={{ fontFamily: FONT, ...style }}>
      {prefix}{val}{suffix}
    </span>
  );
};

// ─── Grid overlay ─────────────────────────────────────────────────────────────
export const Grid: React.FC<{ opacity?: number }> = ({ opacity = 0.05 }) => (
  <svg
    style={{ position: "absolute", top: 0, left: 0, width: W, height: SAFE_H, pointerEvents: "none" }}
    viewBox={`0 0 ${W} ${SAFE_H}`}
  >
    <defs>
      <pattern id="grid" width="108" height="108" patternUnits="userSpaceOnUse">
        <path d="M 108 0 L 0 0 0 108" fill="none" stroke={CREAM} strokeWidth="0.5" opacity={opacity} />
      </pattern>
    </defs>
    <rect width={W} height={SAFE_H} fill="url(#grid)" />
  </svg>
);

// ─── Section label (small caps tag) ──────────────────────────────────────────
export const Tag: React.FC<{ children: React.ReactNode; style?: React.CSSProperties }> = ({
  children, style,
}) => (
  <div
    style={{
      fontFamily: FONT,
      fontSize: 22,
      fontWeight: 500,
      letterSpacing: "0.18em",
      color: CORAL,
      textTransform: "uppercase" as const,
      ...style,
    }}
  >
    {children}
  </div>
);

// ─── Diamond logo mark ────────────────────────────────────────────────────────
export const DiamondMark: React.FC<{
  size?: number; progress?: number; x?: number; y?: number; glow?: boolean;
}> = ({ size = 80, progress = 1, x = 0, y = 0, glow = false }) => {
  const s = size / 2;
  return (
    <svg
      style={{
        position: "absolute",
        left: x - s, top: y - s,
        width: size, height: size,
        transform: `scale(${progress})`,
        transformOrigin: "center",
        filter: glow ? `drop-shadow(0 0 ${20 * progress}px ${CORAL})` : undefined,
      }}
      viewBox={`${-s} ${-s} ${size} ${size}`}
    >
      <polygon
        points={`0,${-s * 0.85} ${s * 0.85},0 0,${s * 0.85} ${-s * 0.85},0`}
        fill="none" stroke={CORAL} strokeWidth="4"
        opacity={progress}
      />
      <polygon
        points={`0,${-s * 0.5} ${s * 0.5},0 0,${s * 0.5} ${-s * 0.5},0`}
        fill="none" stroke={CREAM} strokeWidth="2"
        opacity={progress * 0.7}
      />
    </svg>
  );
};
