import React from "react";
import { useCurrentFrame } from "remotion";
import { CORAL, FPS, clamp, easeOut } from "../constants";

const TRANSITIONS_AT_SECONDS = [4, 8, 14, 20, 26];
const FLASH_DURATION_FRAMES = 4;

export const SceneTransitions: React.FC = () => {
  const frame = useCurrentFrame();

  const flashAlpha = TRANSITIONS_AT_SECONDS.reduce((acc, sec) => {
    const transFrame = sec * FPS;
    const dist = Math.abs(frame - transFrame);
    if (dist < FLASH_DURATION_FRAMES) {
      const t = 1 - dist / FLASH_DURATION_FRAMES;
      return Math.max(acc, t * t * 0.35);
    }
    return acc;
  }, 0);

  if (flashAlpha <= 0) return null;

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        background: CORAL,
        opacity: flashAlpha,
        pointerEvents: "none",
        zIndex: 100,
      }}
    />
  );
};
