// ─── Brand Tokens ────────────────────────────────────────────────────────────
export const CORAL = "#FF7F6A";
export const CORAL_GLOW = "rgba(255,127,106,0.35)";
export const CORAL_FAINT = "rgba(255,127,106,0.08)";
export const CREAM = "#FFF5E8";
export const CREAM_DIM = "rgba(255,245,232,0.55)";
export const CREAM_GHOST = "rgba(255,245,232,0.12)";
export const BG = "#0B0B0B";
export const BG2 = "#111111";

// ─── Composition ─────────────────────────────────────────────────────────────
export const FPS = 30;
export const TOTAL_FRAMES = 900; // 30 s
export const W = 1080;
export const H = 1920;
export const SAFE_H = H * 0.6; // top 60% — safe zone for graphics

// Scene boundaries in seconds → frames
export const SCENE_RANGES = {
  s1: { start: 0,   end: 4   }, // 0–120 f
  s2: { start: 4,   end: 8   }, // 120–240 f
  s3: { start: 8,   end: 14  }, // 240–420 f
  s4: { start: 14,  end: 20  }, // 420–600 f
  s5: { start: 20,  end: 26  }, // 600–780 f
  s6: { start: 26,  end: 30  }, // 780–900 f
} as const;

// ─── Easing helpers ───────────────────────────────────────────────────────────
export const easeOut = (t: number, power = 3) =>
  1 - Math.pow(Math.max(0, 1 - t), power);

export const easeIn = (t: number, power = 3) => Math.pow(Math.max(0, t), power);

export const easeInOut = (t: number) =>
  t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

export const clamp = (v: number, lo = 0, hi = 1) =>
  Math.max(lo, Math.min(hi, v));

export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

/** Normalize frame time within a scene window (0→1) */
export const sceneProgress = (
  frame: number,
  startSec: number,
  endSec: number
) => clamp((frame / FPS - startSec) / (endSec - startSec));

/** Sub-progress within a scene: staggered entrance 0→1 starting at `delay` fraction */
export const subP = (p: number, delay: number, duration = 0.4) =>
  clamp((p - delay) / duration);

// ─── Font stack ───────────────────────────────────────────────────────────────
export const FONT = "'Strichpunkt Sans', 'Space Grotesk', 'Inter', sans-serif";
