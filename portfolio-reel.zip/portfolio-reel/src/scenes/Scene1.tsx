import React from "react";
import { useCurrentFrame } from "remotion";
import {
  CORAL, CREAM, FONT, W, SAFE_H,
  FPS, easeOut, clamp, lerp, sceneProgress, subP,
} from "../constants";
import { Particles, Grid, CoralStreak, GlowDot } from "../components/Primitives";

interface WordProps {
  text: string;
  progress: number;
  color?: string;
  fontSize?: number;
  fontWeight?: number | string;
  offsetX?: number;
}

const Word: React.FC<WordProps> = ({
  text, progress, color = CREAM, fontSize = 96, fontWeight = 700, offsetX = 0,
}) => {
  const e = easeOut(progress);
  return (
    <div
      style={{
        fontFamily: FONT,
        fontSize,
        fontWeight,
        color,
        lineHeight: 1,
        letterSpacing: "-0.03em",
        opacity: e,
        transform: `translateY(${lerp(24, 0, e)}px) translateX(${offsetX * (1 - e)}px)`,
        display: "inline-block",
        willChange: "transform, opacity",
      }}
    >
      {text}
    </div>
  );
};

export const Scene1: React.FC = () => {
  const frame = useCurrentFrame();
  const p = sceneProgress(frame, 0, 4);

  const camScale = lerp(1.06, 1.0, easeOut(p));

  // Word stagger timings
  const w = (delay: number) => easeOut(clamp((p - delay) / 0.35));

  return (
    <div
      style={{
        position: "absolute", inset: 0,
        transform: `scale(${camScale})`,
        transformOrigin: "center 30%",
      }}
    >
      <Grid opacity={0.045 * easeOut(p)} />
      <Particles frame={frame} opacity={0.5 * easeOut(p)} />

      {/* Coral accent streaks */}
      <CoralStreak x={-60} y={280} width={700} height={7} opacity={0.7 * easeOut(clamp((p - 0.05) / 0.3))} />
      <CoralStreak x={400} y={420} width={600} height={4} opacity={0.45 * easeOut(clamp((p - 0.12) / 0.3))} />

      {/* Ambient glows */}
      <GlowDot cx={160} cy={140} radius={160} opacity={0.25 * easeOut(p)} />
      <GlowDot cx={860} cy={240} radius={120} opacity={0.20 * easeOut(p)} />

      {/* Kinetic type block — centred in top-60% */}
      <div
        style={{
          position: "absolute",
          top: 0, left: 0, right: 0,
          height: SAFE_H,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: 12,
          padding: "0 80px",
        }}
      >
        {/* Line 1 */}
        <div style={{ display: "flex", gap: 24 }}>
          <Word text="YOUR"  progress={w(0.00)} color={CREAM} fontSize={112} />
          <Word text="BRAND" progress={w(0.08)} color={CORAL} fontSize={112} />
        </div>

        {/* Line 2 */}
        <div>
          <Word text="DESERVES" progress={w(0.16)} color={CREAM} fontSize={84} fontWeight={500} />
        </div>

        {/* Line 3 — "MORE THAN" small */}
        <div>
          <Word text="MORE THAN" progress={w(0.28)} color={CREAM} fontSize={58} fontWeight={300} />
        </div>

        {/* Coral hero word */}
        <div
          style={{
            marginTop: 8,
            opacity: easeOut(clamp((p - 0.42) / 0.35)),
            transform: `scale(${lerp(0.88, 1, easeOut(clamp((p - 0.42) / 0.35)))})`,
            transformOrigin: "center",
          }}
        >
          <span
            style={{
              fontFamily: FONT,
              fontSize: 88,
              fontWeight: 700,
              color: CORAL,
              letterSpacing: "-0.03em",
              display: "block",
              textAlign: "center",
            }}
          >
            STATIC CONTENT
          </span>
        </div>

        {/* Horizontal rule accent */}
        <div
          style={{
            marginTop: 24,
            width: `${lerp(0, 480, easeOut(clamp((p - 0.65) / 0.35))) }px`,
            height: 2,
            background: `linear-gradient(90deg, transparent, ${CORAL}, transparent)`,
            transition: "width 0.1s",
          }}
        />
      </div>
    </div>
  );
};
