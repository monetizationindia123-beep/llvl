import React from "react";
import { useCurrentFrame } from "remotion";
import {
  CORAL, CREAM, CREAM_DIM, FONT, W, SAFE_H,
  easeOut, clamp, lerp, sceneProgress,
} from "../constants";
import { Particles, GlowDot, DiamondMark } from "../components/Primitives";

const ICONS = [
  // Instagram-style rounded square
  (col: string) => (
    <svg viewBox="0 0 60 60" width="60" height="60">
      <rect x="4" y="4" width="52" height="52" rx="14" fill="none" stroke={col} strokeWidth="3" />
      <circle cx="30" cy="30" r="12" fill="none" stroke={col} strokeWidth="2.5" />
      <circle cx="44" cy="16" r="3.5" fill={col} />
    </svg>
  ),
  // Play button (YouTube-style)
  (col: string) => (
    <svg viewBox="0 0 60 60" width="60" height="60">
      <rect x="4" y="4" width="52" height="52" rx="10" fill="none" stroke={col} strokeWidth="3" />
      <polygon points="22,18 22,42 46,30" fill={col} opacity="0.85" />
    </svg>
  ),
  // TikTok-style note
  (col: string) => (
    <svg viewBox="0 0 60 60" width="60" height="60">
      <path d="M30 6 Q52 6 54 30 Q54 54 30 54 Q6 54 6 30 Q6 6 30 6Z" fill="none" stroke={col} strokeWidth="3" />
      <path d="M38 22 Q38 16 44 16 V22 Q40 22 40 26 V38 H34 V26 Q34 22 38 22Z" fill={col} opacity="0.85" />
    </svg>
  ),
  // Twitter/X bird-ish
  (col: string) => (
    <svg viewBox="0 0 60 60" width="60" height="60">
      <circle cx="30" cy="30" r="26" fill="none" stroke={col} strokeWidth="3" />
      <path d="M16 20 L32 34 L16 44 H20 L36 34 L44 20 H40 L30 30 L22 20Z" fill={col} opacity="0.85" />
    </svg>
  ),
];

const IconCard: React.FC<{
  iconIndex: number; x: number; y: number; progress: number;
}> = ({ iconIndex, x, y, progress }) => {
  const e = easeOut(progress);
  const color = iconIndex % 2 === 0 ? CORAL : CREAM;
  return (
    <div
      style={{
        position: "absolute",
        left: x - 54, top: y - 54,
        width: 108, height: 108,
        border: `1.5px solid ${color}`,
        borderRadius: 20,
        background: `rgba(255,127,106,0.07)`,
        display: "flex", alignItems: "center", justifyContent: "center",
        opacity: e * 0.85,
        transform: `scale(${lerp(0.7, 1, e)}) translateY(${lerp(20, 0, e)}px)`,
      }}
    >
      {ICONS[iconIndex](color)}
    </div>
  );
};

export const Scene2: React.FC = () => {
  const frame = useCurrentFrame();
  const p = sceneProgress(frame, 4, 8);

  const logoP = easeOut(clamp(p * 3.5));
  const flashAlpha = Math.max(0, 1 - p * 10) * 0.2;

  // Icon positions — spread across width
  const iconPositions = [136, 308, 540, 772, 944];

  return (
    <div style={{ position: "absolute", inset: 0 }}>
      <Particles frame={frame} opacity={0.4} />

      {/* Flash on scene cut */}
      {flashAlpha > 0 && (
        <div
          style={{
            position: "absolute", top: 0, left: 0, right: 0, height: SAFE_H,
            background: CORAL, opacity: flashAlpha, pointerEvents: "none",
          }}
        />
      )}

      {/* Logo reveal — centred, upper third */}
      <div
        style={{
          position: "absolute",
          top: 170, left: "50%",
          transform: `translateX(-50%)`,
        }}
      >
        <DiamondMark size={160} progress={logoP} x={80} y={80} glow />
      </div>

      {/* Agency wordmark under logo */}
      <div
        style={{
          position: "absolute",
          top: 360, width: "100%",
          textAlign: "center",
          fontFamily: FONT,
          fontSize: 36,
          fontWeight: 700,
          letterSpacing: "0.28em",
          color: CREAM,
          opacity: easeOut(clamp((p - 0.3) / 0.4)),
          transform: `translateY(${lerp(12, 0, easeOut(clamp((p - 0.3) / 0.4)))}px)`,
        }}
      >
        STUDIO
        <span style={{ color: CORAL }}>.</span>
      </div>

      {/* Social icon row */}
      {iconPositions.map((x, i) => (
        <IconCard
          key={i}
          iconIndex={i % ICONS.length}
          x={x} y={560}
          progress={easeOut(clamp((p - 0.22 - i * 0.06) / 0.35))}
        />
      ))}

      {/* Headline */}
      <div
        style={{
          position: "absolute",
          top: 720, left: "50%",
          transform: "translateX(-50%)",
          width: 920,
          textAlign: "center",
        }}
      >
        {[
          { text: "I CREATE MOTION", color: CREAM,    size: 72, weight: 500, delay: 0.48 },
          { text: "GRAPHICS THAT",   color: CORAL,    size: 80, weight: 700, delay: 0.56 },
          { text: "STOP THE SCROLL", color: CREAM,    size: 66, weight: 400, delay: 0.64 },
        ].map(({ text, color, size, weight, delay }) => {
          const e = easeOut(clamp((p - delay) / 0.35));
          return (
            <div
              key={text}
              style={{
                fontFamily: FONT,
                fontSize: size,
                fontWeight: weight,
                color,
                lineHeight: 1.15,
                letterSpacing: "-0.02em",
                opacity: e,
                transform: `translateY(${lerp(18, 0, e)}px)`,
              }}
            >
              {text}
            </div>
          );
        })}
      </div>

      {/* Bottom glow */}
      <GlowDot cx={540} cy={SAFE_H - 50} radius={180} opacity={0.18 * easeOut(p)} />
    </div>
  );
};
