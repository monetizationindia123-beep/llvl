import React from "react";
import { useCurrentFrame } from "remotion";
import {
  CORAL, CREAM, CREAM_DIM, CREAM_GHOST, FONT, W, SAFE_H,
  easeOut, clamp, lerp, sceneProgress,
} from "../constants";
import { Particles, CoralStreak } from "../components/Primitives";

const CARDS = [
  { label: "WEB ANIMATION",  sub: "Ultra-smooth UX",   accent: CORAL },
  { label: "MOBILE APP",     sub: "iOS & Android",     accent: CREAM },
  { label: "EXPLAINER",      sub: "2D / 3D motion",    accent: CORAL },
  { label: "INFOGRAPHIC",    sub: "Data-driven story",  accent: CREAM },
  { label: "PRODUCT LAUNCH", sub: "360° campaign",     accent: CORAL },
  { label: "3D TRANSITION",  sub: "Cinematic depth",   accent: CREAM },
];

// Floating device mockup in centre
const DeviceMockup: React.FC<{ cardIdx: number; opacity: number; bobY: number }> = ({
  cardIdx, opacity, bobY,
}) => {
  const card = CARDS[Math.min(cardIdx, CARDS.length - 1)];
  return (
    <div
      style={{
        position: "absolute",
        top: 200 + bobY,
        left: "50%",
        transform: "translateX(-50%)",
        width: 400,
        height: 600,
        border: `2px solid ${CORAL}`,
        borderRadius: 32,
        background: "#0d0d0d",
        opacity,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "flex-start",
        overflow: "hidden",
      }}
    >
      {/* Screen header area */}
      <div
        style={{
          width: "100%",
          padding: "36px 32px 24px",
          background: `rgba(255,127,106,0.08)`,
          borderBottom: `1px solid rgba(255,127,106,0.2)`,
        }}
      >
        <div
          style={{
            fontFamily: FONT,
            fontSize: 32,
            fontWeight: 700,
            color: card.accent,
            letterSpacing: "0.06em",
            marginBottom: 8,
          }}
        >
          {card.label}
        </div>
        <div
          style={{
            fontFamily: FONT,
            fontSize: 22,
            color: CREAM_DIM,
          }}
        >
          {card.sub}
        </div>
      </div>

      {/* Fake UI bars */}
      <div style={{ width: "100%", padding: "28px 32px", display: "flex", flexDirection: "column", gap: 16 }}>
        {[280, 200, 240, 160].map((w, i) => (
          <div
            key={i}
            style={{
              width: w,
              height: 18,
              borderRadius: 9,
              background: i === 0 ? CORAL : `rgba(255,245,232,0.15)`,
              opacity: i === 0 ? 0.9 : 0.5,
            }}
          />
        ))}
      </div>

      {/* Fake chart area */}
      <svg width="336" height="120" viewBox="0 0 336 120" style={{ margin: "0 32px" }}>
        <polyline
          points="0,100 50,80 100,60 150,45 200,30 250,18 336,8"
          fill="none"
          stroke={CORAL}
          strokeWidth="3"
          strokeLinecap="round"
        />
        <polygon
          points="0,100 50,80 100,60 150,45 200,30 250,18 336,8 336,120 0,120"
          fill="rgba(255,127,106,0.1)"
        />
      </svg>
    </div>
  );
};

export const Scene3: React.FC = () => {
  const frame = useCurrentFrame();
  const p = sceneProgress(frame, 8, 14);

  const cardIdx = Math.floor(p * CARDS.length * 0.99);
  const t = frame / 30;

  // Bobbing animation
  const bobY = Math.sin(t * 2.8) * 12;

  // Device overall alpha
  const devAlpha = easeOut(clamp(p * 5)) * (1 - easeOut(clamp((p - 0.88) * 8)));

  // Parallax streaks
  const streak1X = lerp(-300, W + 200, easeOut(clamp(p * 1.4)));
  const streak2X = lerp(W + 200, -300, easeOut(clamp(p * 1.4)));

  // Text entrance
  const txtP = clamp((p - 0.55) / 0.4);
  const txtE = easeOut(txtP);

  return (
    <div style={{ position: "absolute", inset: 0 }}>
      <Particles frame={frame} opacity={0.35} />

      {/* Device mockup */}
      <DeviceMockup cardIdx={cardIdx} opacity={devAlpha} bobY={bobY} />

      {/* Parallax streaks */}
      <CoralStreak x={streak1X} y={180} width={360} height={6} opacity={0.65} />
      <CoralStreak x={streak2X} y={700} width={400} height={4} opacity={0.45} />

      {/* Beat-tick indicator dots */}
      <div
        style={{
          position: "absolute",
          bottom: SAFE_H - 870,
          left: "50%",
          transform: "translateX(-50%)",
          display: "flex",
          gap: 16,
        }}
      >
        {CARDS.map((_, i) => (
          <div
            key={i}
            style={{
              width: i === cardIdx ? 48 : 12,
              height: 12,
              borderRadius: 6,
              background: i === cardIdx ? CORAL : `rgba(255,245,232,0.25)`,
              transition: "width 0.15s ease",
            }}
          />
        ))}
      </div>

      {/* Scene headline */}
      <div
        style={{
          position: "absolute",
          top: 890,
          width: "100%",
          textAlign: "center",
          opacity: txtE,
          transform: `translateY(${lerp(18, 0, txtE)}px)`,
        }}
      >
        {[
          { text: "DESIGNED FOR",      color: CREAM, size: 60, weight: 500 },
          { text: "ENGAGEMENT.",       color: CORAL, size: 72, weight: 700 },
          { text: "BUILT FOR RESULTS.", color: CREAM, size: 52, weight: 400 },
        ].map(({ text, color, size, weight }, i) => (
          <div
            key={i}
            style={{
              fontFamily: FONT,
              fontSize: size,
              fontWeight: weight,
              color,
              lineHeight: 1.2,
              letterSpacing: "-0.02em",
              opacity: easeOut(clamp((txtP - i * 0.12) / 0.4)),
            }}
          >
            {text}
          </div>
        ))}
      </div>
    </div>
  );
};
