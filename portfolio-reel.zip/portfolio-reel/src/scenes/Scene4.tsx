import React from "react";
import { useCurrentFrame } from "remotion";
import {
  CORAL, CREAM, CREAM_DIM, FONT, W, SAFE_H,
  easeOut, clamp, lerp, sceneProgress,
} from "../constants";
import { Particles, Counter } from "../components/Primitives";

const METRICS = [
  { value: 320, prefix: "+", suffix: "%", label: "Engagement" },
  { value: 180, prefix: "+", suffix: "%", label: "Watch Time" },
  { value: 240, prefix: "+", suffix: "%", label: "Brand Recall" },
];

const GRAPH_POINTS = [
  [60, 460], [160, 420], [260, 375], [360, 325],
  [460, 265], [560, 200], [660, 145], [780, 90], [940, 42],
] as const;

const MetricCard: React.FC<{
  value: number; prefix: string; suffix: string; label: string;
  progress: number; counterP: number;
  x: number; y: number; width: number;
}> = ({ value, prefix, suffix, label, progress, counterP, x, y, width }) => {
  const e = easeOut(progress);
  return (
    <div
      style={{
        position: "absolute",
        left: x, top: y,
        width, height: 180,
        border: `1.5px solid rgba(255,127,106,0.4)`,
        borderRadius: 20,
        background: "rgba(255,127,106,0.09)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 10,
        opacity: e,
        transform: `translateY(${lerp(24, 0, e)}px)`,
      }}
    >
      <Counter
        target={value}
        progress={easeOut(counterP)}
        prefix={prefix}
        suffix={suffix}
        style={{
          fontFamily: FONT,
          fontSize: 72,
          fontWeight: 700,
          color: CORAL,
          lineHeight: 1,
          letterSpacing: "-0.04em",
        }}
      />
      <div
        style={{
          fontFamily: FONT,
          fontSize: 24,
          color: CREAM_DIM,
          letterSpacing: "0.08em",
          textTransform: "uppercase",
        }}
      >
        {label}
      </div>
    </div>
  );
};

export const Scene4: React.FC = () => {
  const frame = useCurrentFrame();
  const p = sceneProgress(frame, 14, 20);

  const panelE = easeOut(clamp(p * 4));

  // Build animated SVG graph path
  const visiblePts = Math.round(GRAPH_POINTS.length * easeOut(clamp((p - 0.1) / 0.55)));
  let pathD = "";
  if (visiblePts > 0) {
    const pts = GRAPH_POINTS.slice(0, Math.max(visiblePts, 1));
    pathD = `M ${pts.map((pt) => pt.join(",")).join(" L ")}`;
  }

  // Fill path
  let fillD = "";
  if (visiblePts > 1) {
    const pts = GRAPH_POINTS.slice(0, visiblePts);
    const last = pts[pts.length - 1];
    fillD = `M ${pts.map((pt) => pt.join(",")).join(" L ")} L ${last[0]},520 L 60,520 Z`;
  }

  const card0p = easeOut(clamp((p - 0.38) / 0.35));
  const card1p = easeOut(clamp((p - 0.46) / 0.35));
  const card2p = easeOut(clamp((p - 0.54) / 0.35));
  const ctr0  = clamp((p - 0.48) / 0.4);
  const ctr1  = clamp((p - 0.56) / 0.4);
  const ctr2  = clamp((p - 0.64) / 0.4);

  const txtE = easeOut(clamp((p - 0.68) / 0.35));

  return (
    <div style={{ position: "absolute", inset: 0 }}>
      <Particles frame={frame} opacity={0.3} />

      {/* Dashboard panel */}
      <div
        style={{
          position: "absolute",
          top: 56, left: 60, right: 60,
          height: SAFE_H - 112,
          border: `1px solid rgba(255,127,106,0.25)`,
          borderRadius: 36,
          background: "rgba(255,127,106,0.04)",
          opacity: panelE,
        }}
      />

      {/* Panel header */}
      <div
        style={{
          position: "absolute",
          top: 110, left: 120,
          fontFamily: FONT,
          fontSize: 24,
          fontWeight: 500,
          letterSpacing: "0.16em",
          color: CORAL,
          opacity: panelE,
          textTransform: "uppercase",
        }}
      >
        Performance Analytics
      </div>

      {/* Status dots */}
      <div
        style={{
          position: "absolute",
          top: 116, right: 160,
          display: "flex", gap: 12, opacity: panelE,
        }}
      >
        {["#4ade80", CORAL, "#444"].map((c, i) => (
          <div key={i} style={{ width: 14, height: 14, borderRadius: "50%", background: c }} />
        ))}
      </div>

      {/* Animated line chart */}
      <svg
        style={{ position: "absolute", top: 160, left: 60 }}
        width={W - 120}
        height={540}
        viewBox={`0 0 ${W - 120} 540`}
      >
        {/* Grid lines */}
        {[140, 260, 380, 500].map((y) => (
          <line key={y} x1={40} y1={y} x2={W - 160} y2={y}
            stroke="rgba(255,245,232,0.06)" strokeWidth="1" />
        ))}

        {/* Fill */}
        {fillD && (
          <path
            d={fillD}
            fill="rgba(255,127,106,0.1)"
          />
        )}

        {/* Line */}
        {pathD && (
          <path
            d={pathD}
            fill="none"
            stroke={CORAL}
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
            filter="url(#glow)"
          />
        )}

        {/* Glow filter */}
        <defs>
          <filter id="glow">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Bar chart mini */}
        {[90, 130, 110, 155, 180].map((h, i) => (
          <rect
            key={i}
            x={620 + i * 68}
            y={520 - h * easeOut(clamp((p - 0.4) / 0.45))}
            width={44}
            height={h * easeOut(clamp((p - 0.4) / 0.45))}
            rx={4}
            fill={i === 4 ? CORAL : "rgba(255,245,232,0.18)"}
            opacity={easeOut(clamp((p - 0.4) / 0.45))}
          />
        ))}
      </svg>

      {/* Metric cards */}
      <MetricCard {...METRICS[0]} progress={card0p} counterP={ctr0}
        x={70} y={700} width={290} />
      <MetricCard {...METRICS[1]} progress={card1p} counterP={ctr1}
        x={390} y={700} width={290} />
      <MetricCard {...METRICS[2]} progress={card2p} counterP={ctr2}
        x={710} y={700} width={290} />

      {/* Headline */}
      <div
        style={{
          position: "absolute",
          top: 924, width: "100%",
          textAlign: "center",
          opacity: txtE,
          transform: `translateY(${lerp(16, 0, txtE)}px)`,
        }}
      >
        {[
          { text: "RESULTS THAT SPEAK",    color: CREAM, size: 56, weight: 500 },
          { text: "LOUDER THAN WORDS",      color: CORAL, size: 64, weight: 700 },
        ].map(({ text, color, size, weight }) => (
          <div
            key={text}
            style={{
              fontFamily: FONT, fontSize: size, fontWeight: weight,
              color, lineHeight: 1.2, letterSpacing: "-0.02em",
            }}
          >
            {text}
          </div>
        ))}
      </div>
    </div>
  );
};
