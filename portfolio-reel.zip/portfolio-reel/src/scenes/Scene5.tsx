import React from "react";
import { useCurrentFrame } from "remotion";
import {
  CORAL, CREAM, CREAM_DIM, CREAM_GHOST, FONT, W, SAFE_H, FPS,
  easeOut, clamp, lerp, sceneProgress,
} from "../constants";
import { Particles, GlowDot } from "../components/Primitives";

const PORTFOLIO_CARDS = [
  { label: "BRAND VIDEO",   sub: "Cinematic storytelling" },
  { label: "SOCIAL ADS",    sub: "Scroll-stopping content" },
  { label: "PRODUCT FILM",  sub: "Launch reels & demos" },
  { label: "EXPLAINER",     sub: "2D / 3D animation" },
];

const TICKER_TEXT =
  "MOTION GRAPHICS  •  BRAND VIDEOS  •  SOCIAL ADS  •  PRODUCT LAUNCHES  •  EXPLAINER FILMS  •  ";

interface OrbitCardProps {
  label: string; sub: string;
  angle: number; rx: number; ry: number; cx: number; cy: number;
  entranceP: number;
}

const OrbitCard: React.FC<OrbitCardProps> = ({
  label, sub, angle, rx, ry, cx, cy, entranceP,
}) => {
  const x = cx + Math.cos(angle) * rx;
  const y = cy + Math.sin(angle) * ry;
  const depth = (Math.sin(angle) + 1) / 2; // 0 = back, 1 = front
  const scale = lerp(0.60, 1.0, depth);
  const opacity = lerp(0.25, 1.0, depth) * easeOut(entranceP);
  const isFront = depth > 0.55;

  return (
    <div
      style={{
        position: "absolute",
        left: x - 130 * scale,
        top: y - 120 * scale,
        width: 260 * scale,
        height: 240 * scale,
        border: `${isFront ? 2 : 1}px solid ${isFront ? CORAL : "rgba(255,245,232,0.2)"}`,
        borderRadius: 20 * scale,
        background: isFront ? "rgba(255,127,106,0.12)" : "rgba(255,245,232,0.04)",
        opacity,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 8 * scale,
        overflow: "hidden",
        zIndex: Math.round(depth * 10),
        transform: `scale(${easeOut(entranceP)})`,
        transformOrigin: "center",
      }}
    >
      {/* card texture bars */}
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 6, background: isFront ? CORAL : "rgba(255,245,232,0.15)", opacity: 0.5 }} />

      <div style={{
        fontFamily: FONT,
        fontSize: 24 * scale,
        fontWeight: 700,
        color: isFront ? CORAL : CREAM,
        letterSpacing: "0.06em",
        textAlign: "center",
      }}>
        {label}
      </div>
      <div style={{
        fontFamily: FONT,
        fontSize: 16 * scale,
        color: CREAM_DIM,
        textAlign: "center",
      }}>
        {sub}
      </div>

      {/* Decorative lines */}
      {[0, 1].map((i) => (
        <div key={i} style={{
          width: `${(i === 0 ? 65 : 45)}%`,
          height: 2,
          borderRadius: 1,
          background: isFront ? `rgba(255,127,106,0.4)` : `rgba(255,245,232,0.12)`,
        }} />
      ))}
    </div>
  );
};

export const Scene5: React.FC = () => {
  const frame = useCurrentFrame();
  const p = sceneProgress(frame, 20, 26);
  const t = frame / FPS;

  const orbitAngle = t * 0.65;
  const orbitRX = 300;
  const orbitRY = 110;
  const centerX = W / 2;
  const centerY = 380;

  const tickerOffset = (t * 140) % (TICKER_TEXT.length * 15.5);

  const txtE = easeOut(clamp((p - 0.6) / 0.38));

  return (
    <div style={{ position: "absolute", inset: 0 }}>
      <Particles frame={frame} opacity={0.4} />

      {/* Ambient cream glow */}
      <GlowDot cx={centerX} cy={centerY} radius={320} color={CREAM} opacity={0.04 + Math.sin(t * 1.4) * 0.012} />

      {/* Orbit cards */}
      {PORTFOLIO_CARDS.map((card, i) => {
        const angle = orbitAngle + (i * Math.PI * 2) / PORTFOLIO_CARDS.length;
        const entranceP = clamp((p - i * 0.05) * 5);
        return (
          <OrbitCard
            key={i}
            label={card.label}
            sub={card.sub}
            angle={angle}
            rx={orbitRX}
            ry={orbitRY}
            cx={centerX}
            cy={centerY}
            entranceP={entranceP}
          />
        );
      })}

      {/* Orbit ellipse guide */}
      <svg
        style={{ position: "absolute", top: 0, left: 0, width: W, height: SAFE_H, pointerEvents: "none" }}
        viewBox={`0 0 ${W} ${SAFE_H}`}
      >
        <ellipse
          cx={centerX} cy={centerY}
          rx={orbitRX} ry={orbitRY}
          fill="none"
          stroke={`rgba(255,127,106,0.12)`}
          strokeWidth="1"
          strokeDasharray="8 6"
        />
      </svg>

      {/* Ticker strip */}
      <div
        style={{
          position: "absolute",
          top: 700,
          left: 0, right: 0,
          height: 56,
          background: "rgba(255,127,106,0.1)",
          borderTop: `1px solid rgba(255,127,106,0.3)`,
          borderBottom: `1px solid rgba(255,127,106,0.3)`,
          overflow: "hidden",
          display: "flex",
          alignItems: "center",
          opacity: easeOut(clamp(p * 4)),
        }}
      >
        <div
          style={{
            display: "flex",
            whiteSpace: "nowrap",
            transform: `translateX(-${tickerOffset}px)`,
            willChange: "transform",
          }}
        >
          {[0, 1, 2].map((rep) => (
            <span
              key={rep}
              style={{
                fontFamily: FONT,
                fontSize: 22,
                fontWeight: 500,
                letterSpacing: "0.1em",
                color: CORAL,
                paddingRight: 0,
              }}
            >
              {TICKER_TEXT}
            </span>
          ))}
        </div>
      </div>

      {/* Headline */}
      <div
        style={{
          position: "absolute",
          top: 806,
          width: "100%",
          textAlign: "center",
          opacity: txtE,
          transform: `translateY(${lerp(16, 0, txtE)}px)`,
        }}
      >
        {[
          { text: "PREMIUM WORK FOR", color: CREAM, size: 54, weight: 500 },
          { text: "PREMIUM BRANDS",   color: CORAL, size: 72, weight: 700 },
        ].map(({ text, color, size, weight }) => (
          <div
            key={text}
            style={{
              fontFamily: FONT, fontSize: size, fontWeight: weight,
              color, lineHeight: 1.2, letterSpacing: "-0.02em",
            }}
          >
            {text}
          </div>
        ))}
      </div>
    </div>
  );
};
