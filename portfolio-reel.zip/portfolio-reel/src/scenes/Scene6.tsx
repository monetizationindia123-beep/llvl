import React from "react";
import { useCurrentFrame } from "remotion";
import {
  CORAL, CREAM, FONT, W, SAFE_H, FPS,
  easeOut, easeIn, clamp, lerp, sceneProgress,
} from "../constants";
import { Particles, DiamondMark, GlowDot } from "../components/Primitives";

// Stable explosion particles
function buildExplosionParticles(count: number) {
  const particles = [];
  let seed = 77;
  const rng = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };
  for (let i = 0; i < count; i++) {
    const angle = (i / count) * Math.PI * 2 + rng() * 0.3;
    const speed = 120 + rng() * 360;
    const size = 4 + rng() * 12;
    const color = i % 3 === 0 ? CORAL : i % 3 === 1 ? CREAM : "rgba(255,180,140,0.9)";
    const vy = Math.sin(angle) * speed * (0.4 + rng() * 0.3); // vert stretch
    particles.push({ angle, speed, size, color, vy });
  }
  return particles;
}

const EXPLOSION_PARTICLES = buildExplosionParticles(90);

// Burst ring component
const BurstRing: React.FC<{ progress: number; delay: number; cx: number; cy: number }> = ({
  progress, delay, cx, cy,
}) => {
  const rp = easeOut(clamp((progress - delay) * 4));
  const alpha = Math.max(0, (1 - rp) * 0.7);
  if (alpha <= 0) return null;
  return (
    <circle
      cx={cx} cy={cy}
      r={rp * 420}
      fill="none"
      stroke={CORAL}
      strokeWidth={3 - delay * 2}
      opacity={alpha}
    />
  );
};

export const Scene6: React.FC = () => {
  const frame = useCurrentFrame();
  const p = sceneProgress(frame, 26, 30);

  const expP = easeOut(clamp(p * 3));
  const camScale = lerp(1.14, 1.0, easeOut(clamp(p * 2.5)));
  const logoP = easeOut(clamp(p * 5));
  const mainE = easeOut(clamp((p - 0.05) / 0.5));
  const ctaE = easeOut(clamp((p - 0.52) / 0.4));
  const ctaPulse = 1 + Math.sin(frame * 0.2) * 0.015 * ctaE;

  const CX = W / 2;
  const CY = 260;

  return (
    <div
      style={{
        position: "absolute", inset: 0,
        transform: `scale(${camScale})`,
        transformOrigin: `${CX}px ${H * 0.28}px`,
      }}
    >
      <Particles frame={frame} opacity={0.55} />

      {/* Explosion SVG */}
      <svg
        style={{ position: "absolute", top: 0, left: 0, width: W, height: SAFE_H, pointerEvents: "none" }}
        viewBox={`0 0 ${W} ${SAFE_H}`}
      >
        {/* Burst rings */}
        <BurstRing progress={p} delay={0}    cx={CX} cy={CY} />
        <BurstRing progress={p} delay={0.06} cx={CX} cy={CY} />
        <BurstRing progress={p} delay={0.12} cx={CX} cy={CY} />

        {/* Explosion particles */}
        {EXPLOSION_PARTICLES.map((pt, i) => {
          const dist = expP * pt.speed;
          const px = CX + Math.cos(pt.angle) * dist;
          const py = CY + pt.vy * expP;
          if (py > SAFE_H || py < 0 || px < -50 || px > W + 50) return null;
          const alpha = (1 - expP * 0.75) * (pt.size > 10 ? 1 : 0.65);
          const r = pt.size * (1 - expP * 0.35);
          return (
            <circle
              key={i}
              cx={px} cy={py} r={Math.max(1, r)}
              fill={pt.color}
              opacity={Math.max(0, alpha)}
            />
          );
        })}
      </svg>

      {/* Coral ambient glow */}
      <GlowDot cx={CX} cy={CY} radius={280} opacity={0.35 * easeOut(p)} />

      {/* Logo mark */}
      <DiamondMark
        size={200}
        progress={logoP}
        x={CX - 100} y={120}
        glow
      />

      {/* Main headline block */}
      <div
        style={{
          position: "absolute",
          top: 380,
          width: "100%",
          textAlign: "center",
          opacity: mainE,
          transform: `translateY(${lerp(24, 0, mainE)}px)`,
        }}
      >
        {[
          { text: "LET'S MAKE YOUR",      color: CREAM, size: 72, weight: 500 },
          { text: "BRAND",                color: CORAL, size: 100, weight: 700, glow: true },
          { text: "IMPOSSIBLE TO",        color: CREAM, size: 68, weight: 500 },
          { text: "IGNORE",               color: CORAL, size: 96, weight: 700, glow: true },
        ].map(({ text, color, size, weight, glow }, i) => {
          const linE = easeOut(clamp((p - 0.06 - i * 0.04) / 0.45));
          return (
            <div
              key={i}
              style={{
                fontFamily: FONT,
                fontSize: size,
                fontWeight: weight,
                color,
                lineHeight: 1.12,
                letterSpacing: "-0.03em",
                opacity: linE,
                transform: `translateY(${lerp(14, 0, linE)}px)`,
                textShadow: glow ? `0 0 ${40 * linE}px ${CORAL}` : undefined,
              }}
            >
              {text}
            </div>
          );
        })}
      </div>

      {/* CTA pill */}
      <div
        style={{
          position: "absolute",
          top: 870,
          left: "50%",
          transform: `translateX(-50%) scale(${ctaPulse})`,
          transformOrigin: "center",
          width: 540,
          height: 100,
          borderRadius: 50,
          background: CORAL,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          opacity: ctaE,
          boxShadow: `0 0 ${60 * ctaE}px rgba(255,127,106,0.55)`,
        }}
      >
        <span
          style={{
            fontFamily: FONT,
            fontSize: 34,
            fontWeight: 700,
            color: "#fff",
            letterSpacing: "0.1em",
          }}
        >
          DM ME TO GET STARTED
        </span>
      </div>

      {/* Handle / sub-text */}
      <div
        style={{
          position: "absolute",
          top: 996,
          width: "100%",
          textAlign: "center",
          fontFamily: FONT,
          fontSize: 28,
          color: "rgba(255,245,232,0.45)",
          letterSpacing: "0.12em",
          opacity: ctaE,
        }}
      >
        @yourstudio
      </div>
    </div>
  );
};
